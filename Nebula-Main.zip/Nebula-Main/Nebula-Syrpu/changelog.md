# Changelog
### 03/07/2023
* Added Growtopia session stealer.
* Removed tree file generated at the root of the archive.
* Added support for multi-word password of archive.

### 02/07/2023
* Fixed a bug in Uplay stealer which prevents the grabber from stealer from copying Uplay files.
* Removed SSL certificate check in builder.

### 01/07/2023
* Fixed 'AttributeError' in Discord injection.
* Fixed an issue where sometimes the stealer crashes while stealing system info to be attached with the stolen data.

### 29/06/2023
* Added Changelog.
